import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { useCategories } from "@/context/CategoriesContext";
import classes from "@/components/ProductDetails/ProductDetails.module.scss";
import styles from "@/components/ProductDetails/ProductDetails.module.scss";
import clsx from "clsx";
import { Nav, Tab } from "react-bootstrap";
import SimilerProducts from "./SimilerProducts/SimilerProducts";

// ------------------------- QuoteForm -------------------------
const QuoteForm = ({ productName, onClose, onSuccessSubmit }) => {
  const [formData, setFormData] = useState({
    productName: productName || "",
    packQuantity: "",
    companyWebsite: "",
    email: "",
    mobile: "",
    country: "",
    name: "",
    day: "",
    time: "",
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\+?\d{7,15}$/;
    const urlRegex = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/.*)?$/i;

    if (!formData.packQuantity) newErrors.packQuantity = "Required";
    if (!formData.email || !emailRegex.test(formData.email))
      newErrors.email = "Invalid email";
    if (!formData.mobile || !phoneRegex.test(formData.mobile))
      newErrors.mobile = "Invalid mobile number";
    if (!formData.name) newErrors.name = "Required";
    if (formData.companyWebsite && !urlRegex.test(formData.companyWebsite))
      newErrors.companyWebsite = "Invalid URL";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    console.log("Form submitted:", formData);

    // Notify parent to show toast after closing modal
    onClose(); // Close the modal first
    onSuccessSubmit(); // Trigger toast in parent
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <button className={styles.closeBtn} onClick={onClose}>
          ×
        </button>
        <h2 className={styles.title}>Tell Us Your Requirement</h2>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.fullRow}>
            <label className={styles.label}>Enter Product*</label>
            <input
              type="text"
              name="productName"
              value={formData.productName}
              disabled
            />
          </div>

          <div className={styles.halfRow}>
            <div>
              <label className={styles.label}>Pack Quantity (Kg)*</label>
              <input
                type="text"
                name="packQuantity"
                placeholder="Ex: 1000"
                value={formData.packQuantity}
                onChange={handleChange}
              />
              {errors.packQuantity && (
                <span className={styles.error}>{errors.packQuantity}</span>
              )}
            </div>
            <div>
              <label className={styles.label}>Company Website Link</label>
              <input
                type="text"
                name="companyWebsite"
                placeholder="Ex: www.example.com"
                value={formData.companyWebsite}
                onChange={handleChange}
              />
              {errors.companyWebsite && (
                <span className={styles.error}>{errors.companyWebsite}</span>
              )}
            </div>
          </div>

          <div className={styles.halfRow}>
            <div>
              <label className={styles.label}>Email*</label>
              <input
                type="email"
                name="email"
                placeholder="Ex: user@example.com"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && (
                <span className={styles.error}>{errors.email}</span>
              )}
            </div>
            <div>
              <label className={styles.label}>Mobile*</label>
              <input
                type="text"
                name="mobile"
                placeholder="+91 Enter Mobile No."
                value={formData.mobile}
                onChange={handleChange}
              />
              {errors.mobile && (
                <span className={styles.error}>{errors.mobile}</span>
              )}
            </div>
          </div>

          <div className={styles.halfRow}>
            <div>
              <label className={styles.label}>Country</label>
              <select
                name="country"
                value={formData.country}
                onChange={handleChange}
              >
                <option value="">Select Country</option>
                <option value="India">India</option>
                <option value="USA">USA</option>
              </select>
            </div>
            <div>
              <label className={styles.label}>Your Name*</label>
              <input
                type="text"
                name="name"
                placeholder="Enter Your Name"
                value={formData.name}
                onChange={handleChange}
              />
              {errors.name && (
                <span className={styles.error}>{errors.name}</span>
              )}
            </div>
          </div>

          <p className={styles.subNote}>
            Would you be available for a call at your earliest convenience?
          </p>

          <div className={styles.halfRow}>
            <div>
              <label className={styles.label}>Day</label>
              <select name="day" value={formData.day} onChange={handleChange}>
                <option value="">Select Day</option>
                <option>Monday</option>
                <option>Tuesday</option>
                <option>Wednesday</option>
                <option>Thursday</option>
                <option>Friday</option>
              </select>
            </div>
            <div>
              <label className={styles.label}>Time (IST)</label>
              <select name="time" value={formData.time} onChange={handleChange}>
                <option value="">Select Time (IST)</option>
                <option>10:00 AM</option>
                <option>12:00 PM</option>
                <option>3:00 PM</option>
                <option>6:00 PM</option>
              </select>
            </div>
          </div>

          <button type="submit" className={styles.submitBtn}>
            Place an Enquiry
          </button>
        </form>
      </div>
    </div>
  );
};

// ------------------------- ProductDetails -------------------------
const ProductDetails = () => {
  const { productId } = useParams();
  const { categories } = useCategories();
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [showToast, setShowToast] = useState(false);

  const product = categories
    .flatMap((category) => category.products)
    .find((prod) => prod.id === parseInt(productId));

  if (!product) return <p>Product not found</p>;

  const [selectedImage, setSelectedImage] = useState(product.image[0]);
  const [activeTab, setActiveTab] = useState("description");

  const handleSuccessSubmit = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 6000); // Auto hide
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "description":
        return (
          <div
            className="text-start ps-4"
            style={{ backgroundColor: "#e4f3ea" }}
          >
            {product.description}
          </div>
        );
      case "Application":
        return (
          <div className="table-responsive">
            <table className="table table-borderless">
              <tbody>
                {Object.entries(product?.application)?.map(([key, value]) => (
                  <tr key={key}>
                    <td
                      className="text-start "
                      style={{ backgroundColor: "#e4f3ea", width: "16%" }}
                    >
                      <strong>{key}:</strong>
                    </td>
                    <td
                      className="text-start"
                      style={{ backgroundColor: "#e4f3ea" }}
                    >
                      {value}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "Nutritional Value":
        return (
          <div className="table-responsive">
            <table className="table table-borderless">
              <tbody>
                {Object.entries(product?.NutritionalValue)?.map(
                  ([key, value]) => (
                    <tr key={key}>
                      <td
                        className="text-start "
                        style={{ backgroundColor: "#e4f3ea", width: "16%" }}
                      >
                        <strong>{key}:</strong>
                      </td>
                      <td
                        className="text-start"
                        style={{ backgroundColor: "#e4f3ea" }}
                      >
                        {value}
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        );
      default:
        return <div>{product.description}</div>;
    }
  };

  return (
    <section className="mid-section">
      <div className={clsx(classes[""], "d-flex")}>
        <div
          className="d-flex flex-column align-items-center"
          style={{ width: "40%" }}
        >
          <div className={clsx(classes["img-width"])}>
            <img
              className={clsx(classes["img-width"], "p-4 pt-0")}
              src={selectedImage}
              alt={product.name}
            />
          </div>

          <div className="pt-3 d-flex gap-5">
            {product.image.map((img, index) => (
              <div key={index} className="mb-2 d-flex">
                <img
                  src={img}
                  alt={`product-thumbnail-${index}`}
                  className={clsx(
                    classes["thumbnails-images"],
                    "border border-success"
                  )}
                  onClick={() => setSelectedImage(img)}
                />
              </div>
            ))}
          </div>
        </div>

        <div
          className={clsx(
            "d-flex gap-4 flex-column p-2",
            classes["product-background"]
          )}
          style={{ width: "60%" }}
        >
          <div className="d-flex align-items-start pt-4 ps-2">
            <h2>{product.name}</h2>
          </div>

          <div className="table-responsive">
            <table className={clsx("table", classes["table-row"])}>
              <tbody>
                {Object.entries(product?.productSpecification)?.map(
                  ([key, value]) => (
                    <tr key={key}>
                      <td
                        className="text-start"
                        style={{ backgroundColor: "#e4f3ea", width: "25%" }}
                      >
                        <strong>{key}:</strong>
                      </td>
                      <td
                        className="text-start"
                        style={{ backgroundColor: "#e4f3ea" }}
                      >
                        {value}
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>

          <div className="d-flex ps-2">
            <button
              className={clsx("btn", classes["button"], "mb-2")}
              onClick={() => setShowQuoteForm(true)}
            >
              Get Price Quote
            </button>
          </div>
        </div>

        {showQuoteForm && (
          <QuoteForm
            productName={product.name}
            onClose={() => setShowQuoteForm(false)}
            onSuccessSubmit={handleSuccessSubmit}
          />
        )}
      </div>

      <div className="pt-4">
        <Tab.Container
          id="product-tabs"
          activeKey={activeTab}
          onSelect={(k) => setActiveTab(k)}
        >
          <Nav variant="pills" className="mb-3">
            {["description", "Application", "Nutritional Value"].map(
              (tabKey) => (
                <Nav.Item
                  key={tabKey}
                  style={{ backgroundColor: "#e65f382b" }}
                  className="p-2"
                >
                  <Nav.Link
                    eventKey={tabKey}
                    style={{
                      backgroundColor: activeTab === tabKey ? "#e65f38" : "",
                      color: activeTab === tabKey ? "white" : "black",
                    }}
                  >
                    {tabKey}
                  </Nav.Link>
                </Nav.Item>
              )
            )}
          </Nav>
          <Tab.Content>
            <Tab.Pane eventKey={activeTab}>{renderTabContent()}</Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      </div>

      {showToast && (
        <div className={styles.toast}>
          Thanks for your valuable time and interest. Our team will get back to
          you.
        </div>
      )}
      <div>
        <SimilerProducts />
      </div>
    </section>
  );
};

export default ProductDetails;
