import React from "react";
import styles from "./Footer.module.scss";
import logo from "@/assets/Header/ScompanyLogo.png";

const Footer = () => {
  return (
    <div>
      <hr />

      <footer className={styles.footer}>
        <div className={styles.topSection}>
          {/* ✅ Updated About Market layout */}
          <div className={styles.about}>
            <h3>About Market</h3>
            <div className={styles.logoWithText}>
              <img
                src={logo}
                alt="Venkatesh Naturals Logo"
                className={styles.footerLogo}
              />
              <div className={styles.logoText}>
                <ul>
                  <li>
                    <a href="">Home</a>
                  </li>

                  <li>About Us</li>
                  <li>Career</li>
                  <li>ESG</li>
                  <a href="/t">Home</a>
                </ul>
              </div>
            </div>
            <div className={styles.bottomDescription}>
              <p>
                We manufacture high-quality nutraceutical ingredients that serve
                the needs of the food, beverage, and health industries. Our
                innovative solutions are supported by scientific research and
                quality assurance.
              </p>
            </div>
          </div>

          <div className={styles.certifications}>
            <h3>Our Media</h3>
            <div className={styles.icons}>
              <img src="/cert1.png" alt="Cert1" />
              <img src="/cert2.png" alt="Cert2" />
              <img src="/cert3.png" alt="Cert3" />
              <img src="/cert4.png" alt="Cert4" />
              <img src="/cert5.png" alt="Cert5" />
              <img src="/cert6.png" alt="Cert6" />
              <img src="/cert7.png" alt="Cert7" />
            </div>
            <p>
              * These statements have not been evaluated by the Food and Drug
              Administration. These products are not intended to diagnose,
              treat, cure, or prevent any disease.
            </p>
            <div className={styles.socialIcons}>
              <span>🔵</span>
              <span>📷</span>
              <span>💼</span>
              <span>▶️</span>
              <span>❌</span>
            </div>
          </div>

          <div className={styles.contact}>
            <h3>Contact Details</h3>
            <p>
              <strong>Email :</strong> info@naturalecoagro.com
            </p>
            <p>
              <strong>Address :</strong>
            </p>
            <p>
              <strong>Office:</strong> C15, 2nd Floor, DLF Infocity, Pune, India
              - 411005
            </p>
            <p>
              <strong>Warehouse:</strong> Natural Eco Agro, Lane No-2,
              MIDC-Junnar, Junnar, Maharashtra, India - 410504
            </p>
            <p>
              <strong>Phone :</strong>
            </p>
            <p>
              <strong>IN :</strong> +91 935-550-4315
            </p>
            <p>
              <strong>USA :</strong> +1 720-952-9125, +1 702-983-7158
            </p>
          </div>
        </div>

        <div className={styles.bottomSection}>
          <p>© 2025, Jeeva Organic Private Limited. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Footer;
