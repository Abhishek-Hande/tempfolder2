import React from "react";
import styles from "./AboutUs.module.css";

export default function AboutUs() {
  return (
    <section>
      <section id="About-us-banner" className={styles.bannar}>
        <div className="container">
          <div className={styles.bannerElement}>
            <div>
              <h1 className={styles.pageTitle}>About us</h1>

              <div>
                <ul className={styles.breadcrumb}>
                  <li>
                    <a href="http://localhost:5173/">Home </a>
                  </li>
                  <li>About Us</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}
