import React from "react";
import styles from "./WhyChooseUs.module.scss";
import { FaLeaf, FaRecycle, FaHeadset, FaShieldAlt } from "react-icons/fa";

const WhyChooseUs = () => {
  return (
    <section className={styles.whyChooseUs}>
      <h1 className="mid-section" style={{ fontWeight: 360 }}>
        Why Choose us
      </h1>

      <div className={styles.wrapper}>
        <div className={styles.grid}>
          <div className={styles.card}>
            <div className={styles.iconOuter}>
              <div className={styles.iconInner}>
                <FaRecycle />
              </div>
            </div>
            <div className={styles.title}>100% Organic</div>
          </div>
          <div className={styles.card}>
            <div className={styles.iconOuter}>
              <div className={styles.iconInner}>
                <FaLeaf />
              </div>
            </div>
            <div className={styles.title}>100% Customizable</div>
          </div>
          <div className={styles.card}>
            <div className={styles.iconOuter}>
              <div className={styles.iconInner}>
                <FaHeadset />
              </div>
            </div>
            <div className={styles.title}>Support 24/7</div>
          </div>
          <div className={styles.card}>
            <div className={styles.iconOuter}>
              <div className={styles.iconInner}>
                <FaShieldAlt />
              </div>
            </div>
            <div className={styles.title}>Secured Payment</div>
          </div>
        </div>

        <div className={styles.textSection}>
          {/* <p className={styles.subtitle}>~ Why Choose us? ~</p> */}
          <h2 className={styles.heading}>
            We do not buy from the <br /> open market & traders.
          </h2>
          <p className={styles.paragraph}>
            Purchasing from select family farmers who farm organically because
            they believe in it and so we do. We are conscious of air miles and
            our carbon footprint so most of our produce comes from India.
          </p>
          <p className={styles.paragraph}>
            We provide quality in a wide spectrum. Our specifications provide
            the parameters which include physical, chemical, quantification of
            active compounds, estimation of the complete microbial profile,
            residual solvents, pesticides, heavy metals, impurities, related
            substances and Organoleptic parameters etc.
          </p>
          <p className={styles.paragraph}>
            Purchasing from select family farmers who farm organically because
            they believe in it and so we do. We are conscious of air miles and
            our carbon footprint so most of our produce comes from India.
          </p>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
