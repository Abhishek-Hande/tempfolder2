import React from 'react';
import styles from './Header.module.css';

export default function Header() {
  return (
    <header className={styles.stickyHeader}>
      <nav className={styles.navigation}>
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/ae03dc6a617fa2bf2edbe427e0c0fe268f5eaf25731498604f466dc7eb5e29bb?apiKey=ae8e1ab7038f465382b6712342f3c434&"
          className={styles.logo}
          alt="Company Logo"
        />
        <div className={styles.navLinks}>
          <a href="/" className={styles.navLink}>Home</a>
          <div className={styles.dropdownContainer}>
            <a href="/products" className={styles.navLink}>Products</a>
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/8b0fda87e5782a8a55d0c63353108d983e14e6f3de5c681657941d020c47d71b?apiKey=ae8e1ab7038f465382b6712342f3c434&"
              className={styles.dropdownIcon}
              alt=""
            />
            <a href="/b2c" className={styles.navLink}>Exclusive B2C Products</a>
            <a href="/certificates" className={styles.navLink}>Certificates</a>
          </div>
          <a href="/whatsapp" className={styles.whatsappButton}>
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/daafc71100cd2d3c45ee090945dfb01b3bd9df730ab76205fcb63c7d68cbf659?apiKey=ae8e1ab7038f465382b6712342f3c434&"
              className={styles.whatsappIcon}
              alt="WhatsApp Icon"
            />
            <span>WhatsApp</span>
          </a>
          <div className={styles.socialIcons}>
            <a href="/social1" aria-label="Social Media Link">
              <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/67bfc16bc75bd5e3ed22c3208f66120af2595416e08d80a6d4338b8bf4be4442?apiKey=ae8e1ab7038f465382b6712342f3c434&" alt="" className={styles.socialIcon} />
            </a>
            <a href="/social2" aria-label="Social Media Link">
              <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/aea66e7266f5ad160163c5ee1be90d98660a95427d273f2bc6692c7a3c120924?apiKey=ae8e1ab7038f465382b6712342f3c434&" alt="" className={styles.socialIcon} />
            </a>
            <a href="/social3" aria-label="Social Media Link">
              <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/437d63e66915a404094ef5faa5542a651c2cbdcff27e3bb4553dd05b525011f8?apiKey=ae8e1ab7038f465382b6712342f3c434&" alt="" className={styles.socialIcon} />
            </a>
          </div>
        </div>
      </nav>
    </header>
  );
}