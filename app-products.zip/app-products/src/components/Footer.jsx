import React from "react";
import styles from "./Footer.module.css";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.footerContent}>
        <nav className={styles.footerNav} aria-label="Footer Navigation">
          <h2 className={styles.navTitle}>About Market</h2>
          <ul className={styles.navList}>
            <li>
              <a href="/">Home</a>
            </li>
            <li>
              <a href="/about">About Us</a>
            </li>
            <li>
              <a href="/career">Career</a>
            </li>
            <li>
              <a href="/esg">ESG</a>
            </li>
            <li>
              <a href="/blogs">Blogs</a>
            </li>
            <li>
              <a href="/contact">Contact Us</a>
            </li>
            <li>
              <a href="/terms">Terms & Conditions</a>
            </li>
            <li>
              <a href="/privacy">Privacy Policy</a>
            </li>
            <li>
              <a href="/shipping">Shipping Policy</a>
            </li>
          </ul>
        </nav>

        <div className={styles.footerInfo}>
          <img
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/f7918c598502a1cf852b25b4b6e4897d86932fef1c99672a7e671fe4ce8196bc?apiKey=ae8e1ab7038f465382b6712342f3c434&"
            alt="Company Logo"
            className={styles.footerLogo}
          />
          <p className={styles.disclaimer}>
            * These statements have not been evaluated by the Food and Drug
            Administration. These products are not intended to diagnose, treat,
            cure, or prevent any disease.
          </p>
          <img
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/2a3cd90d1e63cc3a18236a63c0c7c180a0d3f60067c0136fe4895fc3033eb9c4?apiKey=ae8e1ab7038f465382b6712342f3c434&"
            alt="Certifications"
            className={styles.certifications}
          />
        </div>

        <div className={styles.contactInfo}>
          <h2 className={styles.contactTitle}>Contact Details</h2>
          <div className={styles.contactDetails}>
            <p>
              <strong>Email:</strong> sales@jeevaorganic.com
            </p>
            <address>
              <strong>Address:</strong>
              <br />
              DCB-705, 7thFloor, DLF Cybercity, Infocity,
              <br />
              Bhubaneswar,751024, India
            </address>
            <p>
              <strong>Phone:</strong>
              <br />
              IN: +91 935-550-4315
              <br />
              USA: +1 702-983-7158
            </p>
          </div>
        </div>
      </div>

      <div className={styles.copyright}>
        <p>© 2025, Natural Eco Agro Private Limited. All Rights Reserved.</p>
      </div>
    </footer>
  );
}
// import { FaLeaf, FaRecycle, FaHeadset, FaShieldAlt } from "react-icons/fa";

// const WhyChooseUs = () => {
//   const cards = [
//     { icon: <FaRecycle />, title: "100% Organic" },
//     { icon: <FaLeaf />, title: "100% Customizable", highlight: true },
//     { icon: <FaHeadset />, title: "Support 24/7" },
//     { icon: <FaShieldAlt />, title: "Secured Payment" },
//   ];
