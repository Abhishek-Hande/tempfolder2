import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import logo from "@/assets/Header/ScompanyLogo.png";
import { Link } from "react-router-dom";
import styles from "@/components/Header/Header.module.scss";

const Header = () => {
  return (
    <Navbar
      bg="light"
      expand="lg"
      fixed="top"
      className={styles.navbar}
      collapseOnSelect
    >
      <Container>
        <Navbar.Brand as={Link} to="/">
          <img
            src={logo}
            alt="Logo"
            style={{ height: "60px", width: "auto" }}
          />
        </Navbar.Brand>

        <Navbar.Toggle
          aria-controls="basic-navbar-nav"
          className={styles.toggle}
        />

        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className={`ms-auto ${styles["navbar-nav"]}`}>
            <Nav.Link as={Link} to="/" className={styles["nav-link"]}>
              Home
            </Nav.Link>

            <NavDropdown
              title="Product Categories"
              id="product-categories-dropdown"
              className={`${styles.dropdown} ${styles["nav-link"]}`}
            >
              <NavDropdown.Item
                as={Link}
                to="category/1"
                className={styles["dropdown-item"]}
              >
                Spray Dried Powder
              </NavDropdown.Item>
              <NavDropdown.Item
                as={Link}
                to="category/2"
                className={styles["dropdown-item"]}
              >
                Dehydrated Vegetable Powder
              </NavDropdown.Item>
              <NavDropdown.Item
                as={Link}
                to="category/3"
                className={styles["dropdown-item"]}
              >
                Dried Fruits And Vegetables
              </NavDropdown.Item>
              <NavDropdown.Item
                as={Link}
                to="category/4"
                className={styles["dropdown-item"]}
              >
                Herbal Powder
              </NavDropdown.Item>
            </NavDropdown>

            <Nav.Link as={Link} to="/aboutUs" className={styles["nav-link"]}>
              About Us
            </Nav.Link>
            <Nav.Link as={Link} to="/contact" className={styles["nav-link"]}>
              Contact Us
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
