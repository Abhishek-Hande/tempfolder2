import React from "react";
import { Row, Col } from "react-bootstrap";
import ProductCard from "@/components/ProductCard/ProductCard";
import { useNavigate, useParams } from "react-router-dom";
import { useCategories } from "@/context/CategoriesContext";

const CategoriesSection = () => {
  const navigate = useNavigate();
  const { categories } = useCategories();
  const { categoryId } = useParams();

  const handleMoreDetails = (categoryId) => {
    navigate(`/category/${categoryId}`);
  };

  return (
    <section id="categories" className="mid-section">
      <div
        className="d-flex justify-content-center align-items-center py-4"
        style={{ backgroundColor: "#fff" }}
      >
        <h1 className="text-center m-0 pt-4" style={{ fontWeight: 360 }}>
          Product Category
        </h1>
      </div>

      <Row className="pt-1">
        {categories.map((category) => (
          <Col key={category.id} md={3} sm={6} xs={12} className="mb-4">
            <ProductCard
              image={category.image}
              title={category.name}
              count={category.count}
              onClick={() => handleMoreDetails(category.id)}
              buttonText="Show Products"
            />
          </Col>
        ))}
      </Row>
    </section>
  );
};

export default CategoriesSection;
