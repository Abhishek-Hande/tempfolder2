import React from "react";
import styles from "./AboutUs.module.scss";
import StatCard from "./StatCard";
import classes from "@/components/AboutUs1/AboutUs.module.scss";

const AboutUs1 = () => {
  return (
    <div className="mid-section">
      <div className={styles.aboutPage}>
        {/* About Company Section */}
        <section className={styles.aboutCompany}>
          <div className={styles.textContent}>
            <h2>About Natural Eco Agro</h2>
            <p>
              Natural Eco Agro is a trusted name in the field of vegetable
              dehydration and dietary ingredient manufacturing. With an
              unwavering commitment to quality, innovation, and sustainability,
              we supply high-grade nutritional ingredients to global markets.
            </p>
            <p>
              Our state-of-the-art facilities and dedicated R&D team help us
              craft natural products that meet international standards. With a
              presence in both domestic and international markets, we pride
              ourselves on being a partner of choice for health-focused
              businesses.
            </p>
          </div>
          <div className={styles.imageContent}>
            <img src="/placeholder-about.jpg" alt="About Natural Eco Agro" />
          </div>
        </section>

        {/* Milestones Section */}
        <section className={styles.milestones}>
          <h2>Our Milestones</h2>
          <ul>
            <li>✅ Founded in 2010 with a focus on sustainable agriculture</li>
            <li>✅ Expanded operations to international markets by 2015</li>
            <li>
              ✅ Established a modern R&D and manufacturing facility in 2018
            </li>
            <li>✅ Served over 200 clients worldwide by 2023</li>
          </ul>
        </section>

        {/* Mission, Vision, Values Section */}
        <section className={styles.mvv}>
          <div className={styles.card}>
            <h3>Our Mission</h3>
            <p>
              To deliver natural, sustainable, and scientifically-backed
              ingredients that contribute to global health and wellness.
            </p>
          </div>
          <div className={styles.card}>
            <h3>Our Vision</h3>
            <p>
              To become a global leader in plant-based and natural nutrition
              solutions by focusing on innovation and purity.
            </p>
          </div>
          <div className={styles.card}>
            <h3>Our Values</h3>
            <p>
              Sustainability, Transparency, Innovation, Customer-Centricity, and
              Integrity guide everything we do.
            </p>
          </div>
        </section>

        {/* Statistics Section */}
        <section className={styles.statsSection}>
          <StatCard
            icon="/icons/client.png"
            number="200+"
            description="Satisfied Clients"
          />
          <StatCard
            icon="/icons/team.png"
            number="30+"
            description="Expert Team"
          />
          <StatCard
            icon="/icons/products.png"
            number="100+"
            description="Active Products"
          />
          <StatCard
            icon="/icons/awards.png"
            number="8+"
            description="Awards Winning"
          />
        </section>

        {/* Clients Section */}
        <section className={styles.clientsSection}>
          <h2>Our Clients</h2>
          <div className={styles.clientLogos}>
            <img src="/clients/client1.png" alt="Client 1" />
            <img src="/clients/client2.png" alt="Client 2" />
            <img src="/clients/client3.png" alt="Client 3" />
            <img src="/clients/client4.png" alt="Client 4" />
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutUs1;
