import React from "react";
import styles from "./StatCard.module.scss";

const StatCard = ({ icon, number, label }) => {
  return (
    <div className={styles.statCard}>
      <div className={styles.iconWrapper}>
        <img src={icon} alt={label} loading="lazy" />
      </div>
      <div className={styles.textWrapper}>
        <h3 className={styles.number}>{number}</h3>
        {/* console.log(label); */}
        <p className={styles.label}>Raja Ratan</p>
      </div>
    </div>
  );
};

export default StatCard;
