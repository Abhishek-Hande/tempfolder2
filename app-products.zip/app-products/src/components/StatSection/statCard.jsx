import React from "react";
import styles from "./StatCard.module.css";

export const StatCard = ({ icon, number, description }) => {
  return (
    <div className={styles.statCard}>
      <div className={styles.cardContent}>
        <div className={styles.iconWrapper}>
          <img loading="lazy" src={icon} className={styles.statIcon} alt="" />
        </div>
        <div className={styles.textContent}>
          <div className={styles.statNumber}>{number}</div>
          <div className={styles.statDescription}>{description}</div>
        </div>
      </div>
    </div>
  );
};
export default StatCard;
