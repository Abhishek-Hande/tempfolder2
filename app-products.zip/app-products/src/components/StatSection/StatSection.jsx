import React, { useState } from "react";
import styles from "./StatSection.module.css";
import StatCard from "./statCard";

export default function StatSection() {
  const stats = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/fd2b407c45dafbd96285d2ebfeb5ac1c24bf3b13ccdd8a1400791bc067c75dfe?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "6+",
      description: "YEARS OF TRUST",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/feee64dca85f1febfa06b7d151671ea4deb5f72e10997485153ac8e5877247cc?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "9+",
      description: "DEDICATED EMPLOYEES",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/44a745da88f72506b11a7ae83d4df85e2481d81c72e0aa8ab9354157b0d95a9a?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "120+",
      description: "SATISFIED CLIENTS",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/320d7d8fef6f94ec8a7a7641065e8c005224cfd7efcb423ab61004e9d1ec72e8?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "35+",
      description: "DIVERSE PRODUCTS",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/c205b75e84cb4de2c53ef016ba911b2f231875e7cd56dd562fc499f9a8a68b7c?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "3+",
      description: "COUNTRIES SERVED",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/aed4061a8749a210afa1504f682aaacbf589977d1790b227e50a5fec5cc94264?placeholderIfAbsent=true&apiKey=ae8e1ab7038f465382b6712342f3c434",
      number: "Sample",
      description: "SAMPLE AVAILABLE AT ANY LOCATION",
    },
  ];

  return (
    <div className=" mid-section">
      <section className={styles.stats}>
        {/* <h2 className={styles.sectionTitle}>
          What makes us better than other Nutraceutical Companies?
        </h2> */}
        <h1 className="text-center m-0 pb-4" style={{ fontWeight: 360 }}>
          What makes us better than other Nutraceutical Companies?
        </h1>
        <div className="container pb-1 pt-1">
          <div className="row g-3">
            {stats.map((stat, index) => (
              <div className="col-md-4 col-6">
                <StatCard key={index} {...stat} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
