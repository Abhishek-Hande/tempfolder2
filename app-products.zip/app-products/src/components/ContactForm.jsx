import React, { useState } from "react";
import styles from "./ContactForm.module.css";

export default function ContactForm() {
  const [formData, setFormData] = useState({
    regarding: "",
    name: "",
    email: "",
    country: "",
    phone: "",
    message: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Form submission logic here
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <form onSubmit={handleSubmit} className={styles.contactForm}>
      <h1 className={styles.formTitle}>We're always here to help you</h1>

      <select
        name="regarding"
        value={formData.regarding}
        onChange={handleChange}
        className={styles.select}
        aria-label="Regarding"
      >
        <option value="">Regarding</option>
      </select>

      <div className={styles.inputRow}>
        <div className={styles.inputGroup}>
          <label htmlFor="name" className="visually-hidden">
            Name
          </label>
          <input
            id="name"
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Name"
            className={styles.input}
          />
        </div>
        <div className={styles.inputGroup}>
          <label htmlFor="email" className="visually-hidden">
            Email
          </label>
          <input
            id="email"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email *"
            required
            className={styles.input}
          />
        </div>
      </div>

      <div className={styles.inputRow}>
        <div className={styles.inputGroup}>
          <label htmlFor="country" className="visually-hidden">
            Country
          </label>
          <input
            id="country"
            type="text"
            name="country"
            value={formData.country}
            onChange={handleChange}
            placeholder="Country"
            className={styles.input}
          />
        </div>
        <div className={styles.inputGroup}>
          <label htmlFor="phone" className="visually-hidden">
            Phone number
          </label>
          <input
            id="phone"
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Phone number"
            className={styles.input}
          />
        </div>
      </div>

      <div className={styles.inputGroup}>
        <label htmlFor="message" className="visually-hidden">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          placeholder="Message"
          className={styles.textarea}
        />
      </div>

      <button type="submit" className={styles.submitButton}>
        Send
      </button>
    </form>
  );
}
