import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Row, Col } from "react-bootstrap";
import ProductCard from "@/components/ProductCard/ProductCard";
import { useCategories } from "@/context/CategoriesContext";
import styles from "@/components/ProductsList/ProductsList.module.scss";
const ProductsList = () => {
  const { id } = useParams();
  const { categories } = useCategories();
  const navigate = useNavigate();

  const category = categories.find((cat) => cat.id === parseInt(id));
  if (!category) return <p>Category not found</p>;

  return (
    <>
      <div>
        <div className={styles.categoryImageDiv}>
          <div>
            <img
              className={styles.categoryImage}
              src={category.categoryImage}
              alt=""
            />
          </div>

          <div className={styles.categoryParagraph}>
            <h4 className={styles.categoryHeader}>
              <strong>{category.categoryHeader}</strong>
            </h4>
            <div>
              {category.categoryDescription.map((para) => (
                <p className={styles.categoryParagraph1}>{para}</p>
              ))}
            </div>
          </div>
        </div>

        {/* <div className={styles.categoryImage}>
          <img
            src="https://cdn.shopify.com/s/files/1/0588/9064/9699/files/Enzymes.jpg?v=1731581525"
            alt="EnzymesCategory Image  EnzymesCategory Image EnzymesCategory Image EnzymesCategory Image"
          />
        </div> */}
        {/* <div>{ca}</div> */}
      </div>
      {/* <div
        id="About-us-banner"
        style={{
          backgroundImage: `url(${category.categoryImage})`,
        }}
        className={styles.bannar}
      >
        <div className="container">
          <div className={styles.bannerElement}>
            <div>
              <h1 className={styles.pageTitle}>About us</h1>

              <div>
                <ul className={styles.breadcrumb}>
                  <li>
                    <a href="/home">Home </a>
                  </li>
                  <li>About Us</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      <div></div>
      <section className="mid-section">
        <Row className="pt-3">
          {category.products.map((product) => (
            <Col key={product.id} md={3}>
              <ProductCard
                image={product.image[0]}
                title={product.name}
                buttonText="Product details"
                onClick={() => navigate(`/product/${product.id}`)}
              />
            </Col>
          ))}
        </Row>
      </section>
    </>
  );
};

export default ProductsList;
