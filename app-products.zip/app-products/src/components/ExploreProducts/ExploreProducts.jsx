import React from "react";
import styles from "./ExploreProducts.module.scss";

const ExploreProducts = () => {
  return (
    <div className={styles.bannerOverlay}>
      <div className={styles.contentBox}>
        <h1 className={styles.heading}>
          India’s Leading Dietary Ingredient Manufacturer
        </h1>
        <p className={styles.subtitle}>
          Where Nature Meets Science for Premium Dietary Ingredients
        </p>
        <button className={styles.button}>Explore Product</button>
      </div>
    </div>
  );
};

export default ExploreProducts;
