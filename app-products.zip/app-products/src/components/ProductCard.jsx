import React from 'react';
import styles from './ProductCard.module.css';

export default function ProductCard({ image, category, title, buttonText }) {
  return (
    <article className={styles.productCard}>
      <img
        loading="lazy"
        src={image}
        className={styles.productImage}
        alt={title}
      />
      <p className={styles.category}>{category}</p>
      <h3 className={styles.title}>{title}</h3>
      <button className={styles.actionButton}>
        <span className={styles.buttonText}>{buttonText}</span>
      </button>
    </article>
  );
}