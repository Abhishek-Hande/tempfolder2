import { useCategories } from "@/context/CategoriesContext";
import { Col, Row } from "react-bootstrap";
import ProductCard from "../ProductCard/ProductCard";
import { useNavigate } from "react-router-dom";

const NewArrival = () => {
  const { newArrival } = useCategories();
  const navigate = useNavigate();
  return (
    <>
      <section id="newArrival" className="mid-section">
        <h1 className="pt-3 pb-2" style={{ fontWeight: 360 }}>
          Featured Products
        </h1>
        <Row className="pt-3">
          {newArrival.map((newArrival) => (
            <Col key={newArrival.id} md={3}>
              <ProductCard
                image={newArrival.image}
                title={newArrival.name}
                // count={newArrival.count}
                onClick={() => navigate(`/product/${newArrival.id}`)}
                buttonText="Show Products"
              />
            </Col>
          ))}
        </Row>
      </section>
    </>
  );
};

export default NewArrival;
