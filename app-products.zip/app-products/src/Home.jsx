import React from 'react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import styles from './HomePage.module.css';

const featuredProducts = [
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/b0c910da4c7d0dce1d8f83d35c16b6d92e2ae7a3cd244d33215fee6929d25bb7?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'Home page',
    title: 'Organic Moringa Leaf Powder',
    buttonText: 'Buy Now'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/6af36da28c5d1d6e0b3dd557bf82e2d9da3f2d46b8f77363d4bd705242c9fc1e?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'Home page',
    title: 'Organic Ashwagandha Root Powder',
    buttonText: 'Buy Now'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/6c7f36f49a175586b1ba3fc70e3cdea6d267be7f0037628a8149059e36539bad?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'Home page',
    title: 'Organic Amla Powder',
    buttonText: 'Buy Now'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/1a9dbbdaee2f2b7dbe888544fd1da33efa16be8bcbed651d3b8af455adba9d08?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'Home page',
    title: 'Organic Beet Root Powder',
    buttonText: 'Buy Now'
  }
];

const newArrivals = [
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/efe44c2abce14d6fdcb1493ee4704c996dc89892be17937a5177c2abc6517040?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'homepage new arrival',
    title: 'Blueberry Fruit Powder',
    buttonText: 'Get Quote'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/df14ba274dc8a1eb8ad8c550de3a50004ef8e94427de1429ec48d8ae45de10b0?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'homepage new arrival', 
    title: 'Cranberry Extract Powder 4:1',
    buttonText: 'Get Quote'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/dd3133cdbf319d74a93c335d1c2b94fe544646041d1306d572e203046db87b77?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'homepage new arrival',
    title: 'Gymnema Leaf Powder',
    buttonText: 'Get Quote'
  },
  {
    image: 'https://cdn.builder.io/api/v1/image/assets/TEMP/2745738ba1a8ff4f17d17d7b1b3bff7a58c2c435e4752d5b7712f66dce28b5c4?apiKey=ae8e1ab7038f465382b6712342f3c434&',
    category: 'homepage new arrival',
    title: 'Psyllium Husk Powder 95% 40 Mesh',
    buttonText: 'Get Quote'
  }
];

export default function HomePage() {
  return (
    <main className={styles.mainContent}>
      <Header />
      
      <section className={styles.hero}>
        <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/1f3dd95c31cab74b2a9f050e3bfedf8e2e17380f618b3cf2f9a98fa9cf7cce7b?apiKey=ae8e1ab7038f465382b6712342f3c434&" alt="" className={styles.heroBackground} />
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            India's Leading Dietary<br />
            Ingredient<br />
            Manufacturer
          </h1>
          <p className={styles.heroSubtitle}>
            Where Nature Meets Science for Premium Dietary<br />
            Ingredients
          </p>
          <button className={styles.exploreButton}>
            Explore Product
          </button>
        </div>
      </section>

      <section className={styles.featuredProducts} aria-labelledby="featured-title">
        <h2 id="featured-title" className={styles.sectionTitle}>Featured products</h2>
        <div className={styles.productGrid}>
          {featuredProducts.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </section>

      <section className={styles.newArrivals} aria-labelledby="new-arrivals-title">
        <h2 id="new-arrivals-title" className={styles.sectionTitle}>New Arrivals</h2>
        <div className={styles.productGrid}>
          {newArrivals.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </section>

      <section className={styles.callToAction}>
        <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/fca581b3c2a8a27c6702ab5da983ab8463d904b7d7872fb64277ca4c24be3bd8?apiKey=ae8e1ab7038f465382b6712342f3c434&" alt="" className={styles.ctaBackground} />
        <div className={styles.ctaContent}>
          <h2 className={styles.ctaTitle}>We Are Right Here To Help You</h2>
          <p className={styles.ctaPhone}>
            <strong>Call Us:</strong> +91 720-533-5111
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.contactContainer}>
          <img
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/722e2f5d026bd2581a997629766f0a0c846c098aa25e9d7342176d2f6c9d5eea?apiKey=ae8e1ab7038f465382b6712342f3c434&"
            alt="Contact illustration"
            className={styles.contactImage}
          />
          <ContactForm />
        </div>
      </section>

      <Footer />
    </main>
  );
}