// src/context/CategoriesContext.jsx
import React, { createContext, useContext } from "react";
import homeCategortImage1 from "@/assets/products/tomatoPowder.jpg";
import homeCategortImage2 from "@/assets/Products/carrot.jpg";

import categoryImage1 from "@/assets/category/EnzymesCategory.jpg";
import categoryImage2 from "@/assets/category/EnzymesCategory.jpg";

import product1 from "@/assets/products/tomatoPowder.jpg";
import product2 from "@/assets/products/carrotSpary.jpg";
import product3 from "@/assets/products/beetroot.jpg";
import product4 from "@/assets/Products/cauliflower.jpg";
import product5 from "@/assets/Products/spinach.jpg";
import product6 from "@/assets/Products/cucumber.jpg";
import product7 from "@/assets/Products/cabbage.jpg";
import product8 from "@/assets/Products/bitterGourd.jpg";

import c2product1 from "@/assets/products/beetroot.jpg";
import c2product2 from "@/assets/products/carrot.jpg";
import c2product3 from "@/assets/products/tomatoPowder.jpg";
import c2product4 from "@/assets/Products/cucumber.jpg";
import c2product5 from "@/assets/Products/cabbage.jpg";
import c2product6 from "@/assets/Products/spinach.jpg";
import c2product7 from "@/assets/Products/cauliflower.jpg";
import c2product8 from "@/assets/Products/greenChilli.jpg";
import c2product9 from "@/assets/Products/bottleGourd.jpg";
import c2product10 from "@/assets/Products/fenugreek.jpg";

import categoryImage3 from "@/assets/aboutUsBannar.jpg";
import categoryImage4 from "@/assets/aboutUsBannar.jpg";
import categoryImage5 from "@/assets/aboutUsBannar.jpg";
import categoryImage6 from "@/assets/aboutUsBannar.jpg";

const CategoriesContext = createContext();

const CategoriesProvider = ({ children }) => {
  const categories = [
    {
      id: 1,
      name: "Spray Dried Powder",
      categoryHeader:
        "Spray dried fruit and vegetable powder manufacturer: Premium quality powder ingredient",
      categoryDescription: [
        "Natural Eco Agro is a premium manufacturer of high-quality spray-dried vegetable powders, dedicated to improving health and well-being across a wide range of industries. With a strong focus on pharmaceutical, nutraceutical, cosmetic, and baby food sectors, Natural Eco Agro delivers top-grade, nutrient-rich vegetable powders that are natural, eco-friendly, and sustainable.",

        "Our spray-dried vegetable powders are packed with essential vitamins, minerals, and antioxidants, offering a clean and natural solution to enhance the nutritional profile of your products. Whether it’s for dietary supplements, cosmetic skincare, baby food, or functional foods, our vegetable powders provide a concentrated, natural source of nutrients that support immune health, skin rejuvenation, digestive well-being, and overall vitality. By using eco-friendly methods and sourcing the finest vegetables, we ensure that our powders retain the full integrity of their natural flavors, nutrients, and health benefits.",
      ],

      image: homeCategortImage1,
      categoryImage: categoryImage1,
      count: 10,
      products: [
        {
          id: 101,
          name: "Spray Dried Tomato Powder",
          description:
            "Spray-Dried Tomato Powder is a high-quality, concentrated powder made from fresh tomatoes, processed through a spray-drying technique that preserves their natural flavor, vibrant color, and nutrients. It offers the authentic taste and nutritional benefits of fresh tomatoes in a convenient, shelf-stable form. Rich in essential vitamins like A, C, and B6, as well as antioxidants such as lycopene, this powder is an ideal ingredient for the food, nutraceutical, and cosmetic industries. Its specialty lies in its ability to enhance the flavor, color, and nutritional profile of products, while providing a longer shelf life and easy incorporation into various applications, from sauces and beverages to supplements and skincare products.",
          image: [product1, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Tomato",
            Appearance: "Fine, Homogeneous powder",
            Color: "Bright brick red",
            Flavor_and_Aroma: "Sweet and sour tangy aroma",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Nutraceuticals:
              "Utilized in health supplements due to its high levels of antioxidants like lycopene, which supports heart health and acts as a natural preservative",
            Cosmetics:
              "Added to formulations for its antioxidant properties, often found in skincare products aimed at reducing signs of aging.",
            Food_Beverage:
              "In the production of ready-to-eat meals, sauces, soups, and seasonings, it provides concentrated tomato flavor and color without the need for refrigeration",
            Snack_Industry:
              "Used as a seasoning in chips, popcorn, and other snack foods to deliver a rich, tangy taste.",
            Frozen_Foods:
              "Incorporated into frozen pizza, pastas, and prepared dishes for enhanced flavor.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~10-20 mg per 100g – Supports immune function, although reduced during drying.",
            Vitamin_A:
              "~1000-1500 IU per 100g – Essential for vision and skin health.",
            Lycopene:
              "~20-30 mg per 100g – A powerful antioxidant linked to heart and cancer risk reduction.",
            Potassium:
              "~2000 mg per 100g – Vital for heart and muscle function.",
            Fiber: "~25-30 g per 100g – Supports digestion and heart health.",
            Calories:
              "~350-400 kcal per 100g – Low in calories, providing concentrated flavor without added fat.",
            Iron: "~3-4 mg per 100g – Important for blood health.",
          },
        },
        {
          id: 102,
          name: "Spray Dried Carrot Powder",
          description:
            "Spray-Dried Carrot Powder is a concentrated, all-natural ingredient derived from fresh carrots through a specialized spray-drying process. This method ensures that the powder retains the full nutritional benefits, including vitamins A, C, and essential antioxidants, along with the natural color and flavor of fresh carrots. It serves as a shelf-stable, easy-to-incorporate option for a wide range of applications in the food, nutraceutical, and cosmetic industries. The powder is ideal for boosting the nutritional profile of products, supporting eye health, immune function, and promoting healthy skin, all while providing a clean-label solution for your formulations.",
          image: [product2, product3, product4],
          productSpecification: {
            Ingredients: "Fresh Carrot",
            Appearance: "Fine, Free-flowing",
            Color: "Bright orange color",
            Flavor_and_Aroma: "Natural Carrot flavor, Mildly sweet",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Nutraceuticals:
              "Carrot powder is added to health supplements for its vitamin A, beta-carotene, and antioxidant content, supporting eye health and immunity.",
            Cosmetics:
              "Sometimes found in skincare products due to its antioxidant properties, promoting skin health and radiance.",
            Baking_Industry:
              "Incorporated into baked goods like muffins, cakes, and bread to add moisture, sweetness, and a nutritional boost.",
            Food_and_Beverage:
              "Used in soups, sauces, baby foods, and snacks for natural color, flavor, and nutritional value, especially in organic or clean-label products.",
            Animal_Feed:
              "Included in animal feed formulations to enhance nutrition, particularly for vitamins and carotenoids.",
          },

          NutritionalValue: {
            Vitamin_A_Beta_Carotene:
              "~8000-10000 IU per 100g – Supports eye health and immune function.",
            Vitamin_C:
              "~10-15 mg per 100g – Antioxidant that aids immune health and skin repair.",
            Potassium:
              "~1500-1800 mg per 100g – Essential for heart and muscle function.",
            Fiber:
              "~25-30 g per 100g – Aids digestion and supports gut health.",
            Calories:
              "~350-400 kcal per 100g – Provides a concentrated, nutrient-dense option.",
            Iron: "~2-3 mg per 100g – Supports oxygen transport in the blood.",
          },
        },
        {
          id: 103,
          name: "Spray Dried Beetroot Powder",
          description:
            "Spray-Dried Beetroot Powder is made by carefully processing fresh beetroots into a fine powder, capturing their natural goodness in a stable, easy-to-use form. This product is packed with essential nutrients like vitamins, minerals, and powerful antioxidants, which support heart health, improve endurance, and assist in detoxification. Unlike fresh beets, this powder offers a longer shelf life and convenience without sacrificing any of the vibrant color or earthy flavor that beets are known for. It’s a versatile ingredient used in a variety of industries, including food, beverages, supplements, and even cosmetics, providing a simple way to boost the nutritional profile of products.",
          image: [product3, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Beetroot",
            Appearance: "Fine, Free-flowing powder",
            Color: "Vibrant Deep red color",
            Flavor_and_Aroma: "Natural, earthy flavor with mildly sweet",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Nutraceuticals:
              "Incorporated into dietary supplements for its high levels of antioxidants, vitamins, and minerals, especially for cardiovascular health.",
            Cosmetics:
              "Included in skincare products for its antioxidant properties, often used to brighten and rejuvenate the skin.",
            Food_Beverage:
              "Used in smoothies, juices, energy bars, snacks, and sauces for its natural color, flavor, and health benefits, such as improving blood circulation and boosting stamina.",
            Baking_Industry:
              "Added to baked goods like cakes, bread, and cookies for color and enhanced nutritional value.",
            Animal_Feed:
              "Used in pet and livestock feed as a natural colorant and for its nutritional content.",
          },

          NutritionalValue: {
            Vitamin_C:
              "~10-15 mg per 100g – Supports immune health and skin repair.",
            Folate:
              "~~100-150 mcg per 100g – Important for cell division and DNA synthesis.",
            Potassium:
              "~1500-2000 mg per 100g – Helps regulate blood pressure and muscle function.",
            Fiber:
              "~20-25 g per 100g – Promotes digestive health and heart health.",
            Iron: "~1.5-2.5 mg per 100g – Supports red blood cell production.",
            Nitrates:
              "~1000-1500 mg per 100g – Known for improving blood flow and athletic performance.",
          },
        },
        {
          id: 104,
          name: "Spray  Dried Cauliflower Powder",
          description:
            "Spray-Dried Cauliflower Powder is a premium, shelf-stable ingredient created by carefully drying fresh cauliflower to preserve its nutritional content, flavor, and versatility. This powder is packed with vitamins, minerals, and fiber, making it an excellent addition to a variety of food products, from soups and sauces to baked goods and snacks. It’s an essential ingredient for boosting the nutritional profile of products while maintaining a clean label. The powder's specialty lies in its ability to provide the health benefits of cauliflower, including support for digestion and detoxification, in a convenient and long-lasting form, ideal for the food, nutraceutical, and wellness industries.",
          image: [product4, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cauliflower",
            Appearance: "Fine, Free-flowing powder",
            Color: "Ligh cream to off-white color",
            Flavor_and_Aroma: "Mild, neutral and slightly earthy test",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Cosmetics:
              "Occasionally used in skincare products due to its antioxidant and anti-inflammatory properties.",
            Health_Supplements:
              "Incorporated into dietary supplements for its high fiber content, vitamins, and antioxidants, supporting digestive and overall health.",
            Food_and_Beverage:
              "Used in gluten-free and low-carb products, such as soups, sauces, snacks, and ready-to-eat meals, to add nutrition and texture.",
            Baking_Industry:
              "Used as a flour substitute in low-carb and keto baking products like bread, pizza crust, and pancakes.",
            Animal_Feed:
              "Added to pet food and livestock feed as a nutrient-rich supplement.",
          },
          NutritionalValue: {
            Vitamin_C:
              "50-60 mg per 100g – Boosts immune function and skin health.",
            Vitamin_K:
              "15-20 mcg per 100g – Supports bone health and blood clotting.",
            Fiber:
              "25-30 g per 100g – Aids digestion and supports heart health.",
            Folate:
              "100-150 mcg per 100g – Important for cell growth and DNA synthesis.",
            Potassium:
              "1000-1500 mg per 100g – Vital for muscle and nerve function.",
            Calories:
              "350-400 kcal per 100g – Low in calories, providing concentrated nutrients.",
          },
        },
        {
          id: 105,
          name: "Spray Dried Spinach Powder",
          description:
            "Spray-Dried Spinach Powder is a concentrated, all-natural ingredient derived from fresh spinach leaves, carefully processed to preserve its vital nutrients. Rich in essential vitamins, minerals, and antioxidants, this powder offers an easy way to add the health benefits of spinach to a variety of products, including functional foods, beverages, and supplements. Its importance lies in its ability to provide all the nutritional goodness of spinach—such as supporting bone health, enhancing immunity, and promoting digestion—in a convenient, long-lasting powder form. The specialty of this powder is that it allows manufacturers to incorporate the power of leafy greens into their products without compromising quality, flavor, or nutritional value.",
          image: [product5, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Spinach",
            Appearance: "Fine, Homogeneous powder",
            Color: "Dark green color",
            Flavor_and_Aroma: " natural spinach flavor and slightly earthy",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Added to smoothies, soups, sauces, snacks, and energy bars to enhance color, flavor, and nutritional value, especially for vitamins A, C, and K.",
            Health_Supplements:
              "Incorporated into dietary supplements for its high levels of iron, antioxidants, and fiber, promoting overall health, digestion, and immunity.",
            Baking_Industry:
              "Used in products like bread, pasta, and tortillas to boost nutritional content and provide a natural green color.",
            Cosmetics:
              "Sometimes included in skincare formulations due to its anti-inflammatory properties and antioxidants, which are beneficial for skin health.",
            Animal_Feed:
              "Added to pet food and livestock feed to enhance nutrition.",
          },
          NutritionalValue: {
            Vitamin_A_Beta_Carotene:
              " ~9000-10000 IU per 100g – Supports eye health and immune function.",
            Vitamin_K:
              " ~800-900 mcg per 100g – Essential for bone health and blood clotting.",
            Iron: " ~20-25 mg per 100g – Supports red blood cell production and oxygen transport.",
            Folate:
              " ~300-400 mcg per 100g – Important for cell growth and DNA synthesis.",
            Vitamin_C:
              " ~30-40 mg per 100g – Boosts immune function and skin health.",
            Magnesium:
              " ~200-250 mg per 100g – Supports muscle and nerve function.",
          },
        },
        {
          id: 106,
          name: "Spray Dried Cucumber Powder",
          description:
            "Lactobacillus fermentum is a gram-positive bacterium, belonging to the Lactobacillus genus. It is commonly found in certain fermenting plant and animal-based materials. This Lactobacillus fermentum powder is basically a free-flowing, white to light-yellow coloured powder. It is known to aid urogenital infections in women.",
          image: [product6, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cucumber",
            Appearance: "Uniform, Free-flowing powder",
            Color: "Light green to off-white color",
            Flavor_and_Aroma: "Natural cucumber flavor and slightly sweet",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in smoothies, snacks, soups, sauces, and beverages for its mild flavor and hydrating properties, as well as its high water content and nutrients.",
            Health_Supplements:
              "Added to dietary supplements for its antioxidants, vitamins, and hydrating benefits, supporting skin health and detoxification.",
            Cosmetics:
              "Incorporated into skincare products like lotions and face masks for its cooling, soothing, and hydrating properties.",
            Animal_Feed:
              "Included in pet food and livestock feed to add nutrients and improve hydration.",
          },
          NutritionalValue: {
            Vitamin_C:
              " ~10-15 mg per 100g – Supports immune health and skin rejuvenation.",
            Vitamin_K:
              " ~10-15 mcg per 100g – Important for bone health and blood clotting.",
            Potassium:
              " ~150-200 mg per 100g – Helps regulate blood pressure and muscle function.",
            Magnesium:
              " ~20-30 mg per 100g – Supports muscle and nerve function.",
            Fiber: " ~5-7 g per 100g – Aids digestion and promotes gut health.",
            Low_in_Calories:
              " ~350-400 kcal per 100g – A light, nutrient-dense option.",
          },
        },
        {
          id: 107,
          name: "Spray Dried Cabbage Powder",
          description:
            "Lactobacillus fermentum is a gram-positive bacterium, belonging to the Lactobacillus genus. It is commonly found in certain fermenting plant and animal-based materials. This Lactobacillus fermentum powder is basically a free-flowing, white to light-yellow coloured powder. It is known to aid urogenital infections in women.",
          image: [product7, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cabbage",
            Appearance: "Fine, Free-flowing powder",
            Color: "Greenish-white",
            Flavor_and_Aroma: "Mild, fresh and slightly earthy",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in soups, sauces, smoothies, snacks, and ready-to-eat meals to enhance flavor, nutrition, and color, providing a rich source of vitamins and minerals.",
            Health_Supplements:
              "Incorporated into dietary supplements for its high levels of fiber, antioxidants, and vitamins C and K, supporting digestion and overall health.",
            Baking_Industry:
              "Added to baked goods, including bread and snacks, to improve nutritional content.",
            Animal_Feed:
              "Included in pet food and livestock feed for its nutritional benefits, particularly in providing vitamins and fiber.",
          },
          NutritionalValue: {
            Vitamin_C:
              " ~30-40 mg per 100g – Supports immune health and skin rejuvenation.",
            Vitamin_K:
              " ~200-250 mcg per 100g – Important for bone health and blood clotting.",
            Folate:
              " ~150-200 mcg per 100g – Aids in cell growth and DNA synthesis.",
            Fiber: " ~25-30 g per 100g – Promotes digestion and heart health.",
            Potassium:
              " ~1000-1500 mg per 100g – Helps regulate blood pressure and muscle function.",
          },
        },
        {
          id: 108,
          name: "Spray Dried Bitter gourd Powder",
          description:
            "Lactobacillus fermentum is a gram-positive bacterium, belonging to the Lactobacillus genus. It is commonly found in certain fermenting plant and animal-based materials. This Lactobacillus fermentum powder is basically a free-flowing, white to light-yellow coloured powder. It is known to aid urogenital infections in women.",
          image: [product8, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Bitter Gourd",
            Appearance: "Fine, Free-flowing powder",
            Color: "Light green to brownish-green color",
            Flavor_and_Aroma:
              "Natural bitter gourd flavor, slightly bitter, fresh and slightly earthy",
            Moisture_content: "5-7%",
            Solubility: "Instantly soluble (100%)",

            Partical_Size:
              "Mesh size of 100-120 micron(As per customer requirements).",
            Shelf_Life: "12 to 18 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in beverages, soups, sauces, and dietary products for its distinctive flavor and health benefits, such as blood sugar regulation and detoxification.",
            Health_Supplements:
              "Added to dietary supplements for its high levels of antioxidants, vitamins, and minerals, supporting blood sugar management, digestion, and immune health.",
            Cosmetics:
              "Incorporated into skincare products for its anti-inflammatory and anti-aging properties, helping to soothe skin and reduce acne.",
            Traditional_Medicine:
              "Used in herbal formulations for its therapeutic properties, especially in treating metabolic and digestive disorders.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~30-40 mg per 100g – Boosts immune function and skin health.",
            Vitamin_A:
              "~1000-1500 IU per 100g – Supports eye health and immune function.",
            Iron: "~2-3 mg per 100g – Helps with red blood cell production.",
            Folate:
              "~100-150 mcg per 100g – Important for cell growth and DNA synthesis.",
            Fiber:
              "~20-25 g per 100g – Aids digestion and promotes gut health.",
            Antioxidants:
              "Includes compounds like cucurbitacin, which may support blood sugar regulation and promote overall health.",
          },
        },
      ],
    },
    {
      id: 2,
      name: "Dehydrated Vegetable Powder",
      categoryHeader:
        "Dehydrated powder manufacturer: Premium Nutrient-Dense powder",
      categoryDescription: [
        "Natural Eco Agro is a trusted manufacturer of high-quality dehydrated vegetable powders, renowned for their natural color, flavor, and aroma. Our nutrient-dense powders are carefully crafted to preserve the full nutritional integrity of the vegetables, making them an ideal solution for industries targeting disease prevention caused by nutrient deficiencies.",

        "These vegetable powders can be seamlessly incorporated into products within the food & beverage, nutraceutical, ayurvedic, cosmetic, and animal care industries. By enriching products with essential vitamins, minerals, and antioxidants, our powders help combat nutrient deficiencies and support overall health. Our dehydrated vegetable powders are made from 100% plant-based, clean-label, and natural ingredients, providing a pure and nutrient-rich solution for enhancing health and wellness.",
      ],
      description:
        " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
      image: homeCategortImage2,
      categoryImage: categoryImage2,
      count: 23,
      products: [
        {
          id: 201,
          name: "Dehydrated Beetroot Powder",
          description:
            "Dehydrated Beetroot Powder is a natural, nutrient-dense powder made from fresh beets, carefully dehydrated to preserve their rich color, flavor, and essential nutrients. Packed with vitamins, minerals, and antioxidants like betalains, it supports heart health, boosts stamina, and aids in detoxification. Its importance lies in offering a shelf-stable, convenient form of beetroot that can be easily incorporated into various food products, beverages, and supplements. The specialty of this powder is its ability to provide all the health benefits of fresh beets in a concentrated, long-lasting format, making it a versatile ingredient for the food, nutraceutical, and wellness industries.",
          image: [c2product1, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Beetroot",
            Appearance: "Fine, slightly Coarse texture",
            Color: "Dark red color",
            Flavor_and_Aroma: "Stronger, earthy flavor",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in smoothies, energy drinks, snacks, soups, sauces, and baked goods for its natural color, flavor, and nutritional benefits, especially for boosting stamina and supporting heart health.",
            Health_Supplements:
              "Added to dietary supplements for its high levels of antioxidants, vitamins, and minerals, including folate and fiber, supporting overall health.",
            Cosmetics:
              "Included in skincare products for its antioxidant properties, which help improve skin health and promote a natural glow.",
            Animal_Feed:
              "Used in pet food and livestock feed to enhance nutritional value and improve overall health.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~10-15 mg per 100g – Boosts immune health and skin repair.",
            Folate:
              "~100-150 mcg per 100g – Important for cell division and DNA synthesis.",
            Potassium:
              "~1500-2000 mg per 100g – Supports heart and muscle function.",
            Fiber:
              "~20-25 g per 100g – Aids digestion and promotes gut health.",
            Iron: "~1.5-2.5,5 mg per 100g – Supports oxygen transport in the blood.",
            Nitrates:
              "~1000-1500 mg per 100g – Known to improve blood flow and athletic performance.",
          },
        },
        {
          id: 202,
          name: "Dehydrated Carrot Powder",
          description:
            "Dehydrated Carrot Powder is a nutrient-rich powder made from fresh carrots that are carefully dehydrated to retain their natural flavor, color, and essential vitamins like A, C, and K. This powder is packed with antioxidants and dietary fiber, promoting eye health, boosting immunity, and supporting digestion. Its importance lies in providing a convenient, shelf-stable option to incorporate the health benefits of carrots into a variety of food, beverage, and supplement products. The specialty of this powder is its ability to offer all the nutritional advantages of fresh carrots in a concentrated, easy-to-use form, making it perfect for the food and wellness industries.",
          image: [c2product2, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Carrot",
            Appearance: "Fine, slightly Coarse texture",
            Color: "Dark brownish-orange color",
            Flavor_and_Aroma: "Mildly sweet and earthy",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in soups, sauces, smoothies, snack seasonings, and baby foods for its natural sweetness, color, and nutritional benefits, such as high vitamin A content.",
            Health_Supplements:
              "Incorporated into dietary supplements for its antioxidant properties, vitamins, and beta-carotene, promoting eye health and immune support.",
            Baking_Industry:
              "Added to baked goods like cakes, muffins, and bread to improve flavor, texture, and nutritional value.",
            Animal_Feed:
              "Used in pet food and livestock feed to enhance nutrition, particularly for providing essential vitamins and fiber.",
          },
          NutritionalValue: {
            Vitamin_A_Beta_Carotene:
              "~8000-10000 IU per 100g – Supports eye health and immune function.",
            Vitamin_C:
              "~10-15 mg per 100g – Boosts immune health and skin repair.",
            Potassium:
              "~1500-2000 mg per 100g – Supports heart health and muscle function.",
            Fiber:
              "~25-30 g per 100g – Aids digestion and supports gut health.",
            Iron: "~2-3 mg per 100g – Important for blood health and oxygen transport.",
          },
        },
        {
          id: 203,
          name: "Dehydrated Tomato Powder",
          description:
            "Dehydrated Tomato Powder is a high-quality, natural powder made from fresh tomatoes, carefully processed to preserve their rich flavor, vibrant color, and essential nutrients. This powder is packed with vitamins, antioxidants, and lycopene, making it an excellent addition to food products aimed at supporting heart health and boosting immunity. Its importance lies in offering a shelf-stable, convenient form of tomatoes that retains all the benefits of fresh produce, ideal for use in sauces, soups, snacks, and nutritional supplements. The specialty of this powder is its ability to deliver the natural goodness of tomatoes in a concentrated, easy-to-incorporate format, perfect for manufacturers seeking a clean-label, nutritious ingredient.",
          image: [c2product3, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Tomato",
            Appearance: "Fine and granular texture",
            Color: "Dark red color",
            Flavor_and_Aroma: "Mildly sweet and earthy",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "8 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in sauces, soups, dressings, pasta sauces, and ready-to-eat meals for concentrated tomato flavor and color.",
            Snack_Industry:
              "Incorporated into snack seasonings like chips, popcorn, and crackers for rich, tangy flavor.",
            Baking_Industry:
              "Added to breads, pizza crusts, and other baked goods to enhance taste and nutrition.",
            Nutraceuticals:
              "Used in dietary supplements for its high vitamin C, lycopene, and antioxidants, supporting heart and immune health.",
            Animal_Feed:
              "Included in pet food and livestock feed to provide added nutrients and flavor.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~10-15 mg per 100g – Supports immune function and skin health.",
            Vitamin_A_Beta_Carotene:
              "~1000-1500 IU per 100g – Promotes eye health and immunity.",
            Lycopene:
              "~20-30 mg per 100g – A powerful antioxidant that supports heart health and may reduce cancer risk.",
            Potassium:
              "~2000-2500 mg per 100g – Helps maintain blood pressure and muscle function.",
            Fiber:
              "~25-30 g per 100g – Aids digestion and supports gut health.",
          },
        },
        {
          id: 204,
          name: "Dehydrated Cucumber Powder",
          description:
            "Dehydrated Cucumber Powder is a natural, finely milled powder made from fresh cucumbers, carefully dehydrated to retain their refreshing flavor and nutritional benefits. This powder is packed with vitamins, minerals, and antioxidants that support hydration, promote skin health, and aid in digestion. Its importance lies in providing a shelf-stable, easy-to-use version of cucumber, perfect for incorporating into a wide range of products such as beverages, skincare formulations, and health supplements. The specialty of this powder is its ability to deliver the cooling, soothing properties of fresh cucumbers in a concentrated, long-lasting form, offering convenience and versatility for manufacturers in the food, wellness, and cosmetic industries.",
          image: [c2product4, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cucumber",
            Appearance: "Fine and course texture",
            Color: "Light green to brownish-green",
            Flavor_and_Aroma: "Earthy, slightly sweet and mild flavor",
            Moisture_content: "7-10%",
            Solubility: "94%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Used in smoothies, soups, sauces, and salad dressings for flavor and nutrition.",
            Health_Supplements:
              "Added to supplements for hydration, skin health, and antioxidant benefits.",
            Cosmetics:
              "Incorporated into skincare products like masks and lotions for soothing and hydrating properties.",
            Animal_Feed:
              "Included in pet food and livestock feed to enhance nutrition and flavor.",
          },
          NutritionalValue: {
            Vitamin_C: "~5-10 mg per 100g – Supports immunity and skin health.",
            Vitamin_K:
              "~16-20 µg per 100g – Essential for blood clotting and bone health.",
            Potassium:
              "~500-800 mg per 100g – Regulates fluid balance and supports muscle function.",
            Magnesium: "~30-50 mg per 100g – Aids muscle and nerve function.",
            Fiber: "~5-8g per 100g – Promotes digestion and gut health.",
            Low_in_Calories:
              "~20-30 calories per 100g – Ideal for weight management.",
          },
        },
        {
          id: 205,
          name: "Dehydrated Cabbage Powder",
          description:
            "Dehydrated Cabbage Powder is a nutrient-dense powder made from fresh cabbage that is carefully dehydrated to preserve its natural flavor, color, and essential nutrients. Rich in vitamins C and K, fiber, and antioxidants, this powder provides numerous health benefits, including supporting digestion, promoting heart health, and boosting immunity. Its importance lies in offering a convenient, long-lasting way to incorporate the goodness of cabbage into various products, including soups, smoothies, and dietary supplements. The specialty of this powder is its versatility and clean-label appeal, making it a valuable ingredient for manufacturers seeking to add natural nutrition to their offerings without compromising on quality.",
          image: [c2product5, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cabbage",
            Appearance: "Fine and granular texture",
            Color: "Light green color",
            Flavor_and_Aroma: "Intense and natural cabbage flavor",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into soups, sauces, smoothies, and baked goods to enhance flavor, color, and nutritional value.",
            Health_Supplements:
              "Added to dietary supplements for its high fiber, vitamins, and antioxidants, supporting digestive health and overall well-being.",
            Animal_Feed:
              "Used in pet food and livestock feed to provide essential nutrients and improve palatability.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~30-50 mg per 100g – Supports immunity and skin health.",
            Vitamin_K:
              "~100-150 µg per 100g – Crucial for blood clotting and bone health.",
            Folate_Vitamin_B:
              "~100-150 µg per 100g – Important for cell division and prenatal health.",
            Potassium:
              "~400-600 mg per 100g – Helps maintain fluid balance and muscle function.",
            Calcium: "~150-200 mg per 100g – Supports bone and dental health.",
            Fiber: "~20-25g per 100g – Aids digestion and promotes gut health.",
            Antioxidants:
              "Contains various compounds like flavonoids that support overall health.",
          },
        },
        {
          id: 206,
          name: "Dehydrated Spinach Powder",
          description:
            "Dehydrated Spinach Powder is a premium powder made from fresh spinach leaves that are gently dehydrated to maintain their vibrant green color, flavor, and rich nutritional profile. Packed with essential vitamins like A, C, K, and folate, along with powerful antioxidants, this powder supports immunity, bone health, and overall wellness. Its importance lies in providing a convenient, shelf-stable way to incorporate the health benefits of spinach into a wide range of applications, from smoothies and soups to supplements and snacks. The specialty of this powder is its ability to retain the natural goodness of spinach in a concentrated, easy-to-use form, making it ideal for manufacturers in the food, nutraceutical, and wellness industries.",
          image: [c2product6, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Spinach",
            Appearance: "Fine and corser texture",
            Color: "Darker green color",
            Flavor_and_Aroma: "More earthy",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into soups, sauces, smoothies, and baked goods to enhance flavor, color, and nutritional value.",
            Health_Supplements:
              "Added to dietary supplements for its high levels of vitamins, minerals, and antioxidants, supporting overall health.",
            Baking_Industry:
              "Used in products like bread, pasta, and tortillas to boost nutritional content and provide a natural green color.",
            Animal_Feed:
              "Included in pet food and livestock feed to enhance nutrition.",
          },
          NutritionalValue: {
            Vitamin_A:
              "~9000-10000 IU per 100g – Supports vision, immune function, and skin health.",
            Vitamin_K:
              "~800-900 µg per 100g – Essential for blood clotting and bone health.",
            Iron: "~15-20 mg per 100g – Helps with oxygen transport and energy production.",
            Magnesium:
              "~150-200 mg per 100g – Supports muscle function and bone health.",
            Folate_Vitamin_B9:
              "~200-250 µg per 100g – Important for cell growth and DNA synthesis.",
            Calcium: "~150-250 mg per 100g – Aids in bone and teeth health.",
            Potassium:
              "~1000-1500 mg per 100g – Helps with fluid balance and muscle function.",
            Fiber: "~15-20g per 100g – Aids digestion and supports gut health.",
          },
        },
        {
          id: 207,
          name: "Dehydrated Cauliflower Powder",
          description:
            "Dehydrated Cauliflower Powder is a versatile, nutrient-rich powder derived from fresh cauliflower, carefully dehydrated to preserve its natural taste and health benefits. This powder is packed with vitamins C and K, fiber, and antioxidants, which support digestive health, promote heart health, and boost immunity. Its importance lies in providing a convenient, shelf-stable way to incorporate cauliflower’s benefits into a variety of products, such as soups, snacks, and dietary supplements. The specialty of this powder is its ability to deliver all the nutritional goodness of fresh cauliflower in a concentrated, easy-to-integrate form, making it ideal for manufacturers looking to add a healthy, clean-label ingredient to their offerings.",
          image: [c2product7, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Cauliflower",
            Appearance: "Fine and corser texture",
            Color: "off-white color",
            Flavor_and_Aroma: "Earthy with strong cooked vegetable test",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into soups, sauces, smoothies, and baked goods to enhance flavor, color, and nutritional value.",
            Health_Supplements:
              "Added to dietary supplements for its high levels of vitamins, minerals, and antioxidants, supporting overall health.",
            Baking_Industry:
              "Used as a gluten-free flour substitute in products like bread, pizza crusts, and pasta, catering to low-carb and ketogenic diets.",
            Animal_Feed:
              "Included in pet food and livestock feed to enhance nutrition.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~40-50 mg per 100g – Boosts immunity and acts as an antioxidant.",
            Vitamin_K:
              "~15-20 µg per 100g – Important for blood clotting and bone health.",
            Folate_Vitamin_B9:
              "~50-70 µg per 100g – Supports cell function and growth.",
            Potassium:
              "~500-700 mg per 100g – Helps regulate fluid balance and muscle function.",
            Fiber:
              "~20-25g per 100g – Promotes healthy digestion and gut health.",
            Calcium: "~40-60 mg per 100g – Supports bone health.",
            Antioxidants:
              "Contains glucosinolates, compounds linked to cancer protection and overall health.",
          },
        },
        {
          id: 208,
          name: "Dehydrated green chilli Powder",
          description:
            "Dehydrated Green Chili Powder is a flavorful, all-natural powder made from fresh green chilies that are carefully dehydrated to preserve their spicy kick, vibrant color, and nutrients. This powder is rich in vitamins A and C, capsaicin, and antioxidants, providing health benefits like boosting metabolism, enhancing digestion, and promoting skin health. Its importance lies in offering a shelf-stable, easy-to-use alternative to fresh green chilies, ideal for adding heat and flavor to a wide range of products, including sauces, seasonings, and snacks. The specialty of this powder is its concentrated form, allowing manufacturers to infuse the natural spiciness and health benefits of green chilies into their products without compromising on quality or freshness.",
          image: [c2product8, product2, product3],
          productSpecification: {
            Ingredients: "Fresh green chilli",
            Appearance: "Fine to medium texture",
            Color: "Geen to light brown color",
            Flavor_and_Aroma: "spicy pungent and sharp flavor",
            Moisture_content: "6-8%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into sauces, soups, marinades, and spice blends to add heat and flavor.",
            Snack_Industry:
              "Used in seasoning blends for chips, popcorn, and other snack foods to provide a spicy kick.",
            Baking_Industry:
              "Added to bread, crackers, and other baked goods to introduce a subtle heat and unique flavor profile.",
            Health_Supplements:
              "Included in dietary supplements for its capsaicin content, which may support metabolism and weight management.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~70-100 mg per 100g – Boosts immunity and acts as an antioxidant.",
            Vitamin_A_Beta_carotene:
              "~5000-7000 IU per 100g – Supports vision and skin health.",
            Capsaicin:
              "~1-3% per 100g – Provides a spicy kick and has metabolism-boosting and pain-relief properties.",
            Potassium:
              "~500-700 mg per 100g – Helps regulate fluid balance and muscle function.",
            Iron: "~4-6 mg per 100g – Supports oxygen transport and energy production.",
            Fiber:
              "~10-15g per 100g – Promotes digestion and supports gut health.",
          },
        },
        {
          id: 209,
          name: "Dehydrated Bottle Gourd Powder",
          description:
            "Dehydrated Bottle Gourd Powder is a natural, nutrient-packed powder made from fresh bottle gourd, carefully dehydrated to preserve its mild flavor and health benefits. Rich in vitamins, minerals, and water content, this powder supports hydration, aids digestion, and helps in detoxification. Its importance lies in offering a shelf-stable, easy-to-use form of bottle gourd that can be easily incorporated into food products, beverages, and supplements. The specialty of this powder is its ability to retain the benefits of fresh bottle gourd in a concentrated, long-lasting form, making it a valuable ingredient for manufacturers in the food, wellness, and nutraceutical industries.",
          image: [c2product9, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Bottle Gourd ",
            Appearance: "Fine texture",
            Color: "Light greenish color",
            Flavor_and_Aroma: "Mild, neutral flavor",
            Moisture_content: "6-8%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              " Incorporated into soups, sauces, smoothies, and baked goods to enhance flavor, color, and nutritional value.",
            Health_Supplements:
              " Added to dietary supplements for its high levels of vitamins, minerals, and antioxidants, supporting overall health.",
            Baking_Industry:
              " Used as a gluten-free flour substitute in products like bread, pizza crusts, and pasta, catering to low-carb and ketogenic diets.",
            Animal_Feed:
              " Included in pet food and livestock feed to enhance nutrition.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~10-20 mg per 100g – Supports immunity and acts as an antioxidant.",
            Vitamin_A:
              "~300-500 IU per 100g – Promotes good vision and skin health.",
            Calcium: "~20-30 mg per 100g – Supports bone health.",
            Iron: "~1-2 mg per 100g – Important for oxygen transport and energy production.",
            Potassium:
              "~300-400 mg per 100g – Helps regulate fluid balance and muscle function.",
            Fiber: "~10-15g per 100g – Aids digestion and supports gut health.",
            Magnesium:
              "~30-40 mg per 100g – Supports muscle and nerve function.",
          },
        },
        {
          id: 210,
          name: "Dehydrated fenugreek Powder",
          description:
            "Dehydrated Fenugreek Leaves Powder is a natural, nutrient-rich powder made from fresh fenugreek leaves, carefully dehydrated to preserve their flavor, aroma, and health benefits. Packed with essential vitamins, minerals, and antioxidants, this powder supports digestive health, helps regulate blood sugar, and promotes healthy skin and hair. Its importance lies in offering a convenient, shelf-stable form of fenugreek leaves, making it easy to incorporate into a wide range of products such as supplements, teas, and health foods. The specialty of this powder is its ability to deliver the medicinal and nutritional benefits of fenugreek in a concentrated, long-lasting format, ideal for clean-label and wellness-focused products.",
          image: [c2product10, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Fenugreek",
            Appearance: "Fine texture",
            Color: "Dark green",
            Flavor_and_Aroma: "Bitter,hearbal aromatic",
            Moisture_content: "6-8%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into curries, soups, sauces, and spice blends to enhance flavor and aroma.",
            Health_Supplements:
              "Added to dietary supplements for its potential health benefits, including supporting digestion and regulating blood sugar levels.",
            Cosmetics:
              "Used in skincare products for its antioxidant and anti-inflammatory properties.",
            Animal_Feed:
              "Included in livestock feed to improve digestion and overall health.",
          },
          NutritionalValue: {
            Vitamin_C:
              "~40-50 mg per 100g – Boosts immunity and acts as an antioxidant.",
            Vitamin_A:
              "~2000-3000 IU per 100g – Supports vision, skin, and immune health.",
            Iron: "~15-20 mg per 100g – Essential for oxygen transport and energy production.",
            Folate_Vitamin_B:
              "~100-150 µg per 100g – Aids in cell growth and DNA synthesis.",
            Calcium: "~200-300 mg per 100g – Supports bone health.",
            Magnesium:
              "~100-150 mg per 100g – Helps muscle and nerve function.",
            Fiber: "~25-30g per 100g – Promotes digestion and gut health.",
          },
        },
      ],
    },
    {
      id: 3,
      name: "Dried Fruits And Vegetables",
      categoryHeader:
        "Dried vegetable flakes manufacturer: easy-to-use solution for today’s fast-paced lifestyle",
      categoryDescription: [
        "Natural Eco Agro is a leading manufacturer of high-quality dried vegetable flakes, offering a convenient, easy-to-use solution for today’s fast-paced lifestyle. Our flakes are processed under low temperatures to retain the natural color, flavor, and nutrition of the vegetables, ensuring that every flake is packed with the goodness of fresh vegetables.",

        "These flakes can be effortlessly rehydrated, regaining their original texture, making them a perfect ready-to-cook product that saves both time and energy. Ideal for those seeking a quick, nutritious, and flavorful addition to their meals, our vegetable flakes provide a hassle-free, health-boosting option for modern cooking.",
      ],
      description:
        " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
      image: product3,
      categoryImage: categoryImage1,
      count: 14,
      products: [
        {
          id: 301,
          name: "Organic Grains",
          description:
            " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
          image: [product3, product2, product4],
          potency: "5 billion – 100 billion CFU/g",
          source: "Vegetables",
          packaging: "1 kg & 2 kg aluminum foil bags.",
        },
        {
          id: 302,
          name: "Organic Grains",
          description:
            " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
          image: [product3, product2, product4],
          potency: "5 billion – 100 billion CFU/g",
          source: "Vegetables",
          packaging: "1 kg & 2 kg aluminum foil bags.",
        },
        {
          id: 303,
          name: "Organic Grains",
          description:
            " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
          image: [product3, product2, product4],
          potency: "5 billion – 100 billion CFU/g",
          source: "Vegetables",
          packaging: "1 kg & 2 kg aluminum foil bags.",
        },
        {
          id: 304,
          name: "Organic Grains",
          description:
            " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
          image: [product3, product2, product4],
          potency: "5 billion – 100 billion CFU/g",
          source: "Vegetables",
          packaging: "1 kg & 2 kg aluminum foil bags.",
        },
        {
          id: 305,
          name: "Organic Grains",
          description:
            " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
          image: [product3, product2, product4],
          potency: "5 billion – 100 billion CFU/g",
          source: "Vegetables",
          packaging: "1 kg & 2 kg aluminum foil bags.",
        },
      ],
    },
    {
      id: 4,
      name: "Herbal Powder",
      categoryHeader:
        "Dried herbs manufacturer: Enhancing Health with Herb Powders",
      categoryDescription: [
        "Natural Eco Agro is a trusted manufacturer of dried herbs, offering natural solutions that promote health and well-being. Rooted in the wisdom of traditional Ayurvedic practices, our dried herbs provide powerful, time-tested remedies for a variety of health concerns. By carefully sourcing and processing these herbs, we ensure that each product retains its natural potency, delivering a pure, nutrient-rich option for modern wellness needs.",

        "Our herbs are crafted to support a healthy lifestyle, offering solutions for disease prevention, immune support, and overall vitality. Whether you're incorporating them into nutraceuticals, herbal teas, or natural wellness products, our dried herbs drive the benefits of ancient Ayurvedic wisdom into today's health-conscious world, providing a natural, sustainable approach to holistic health.",
      ],
      description:
        " It aids weight management by keeping you satiated for a longer time and preventing hunger pangs that often otherwise lead to unhealthy snacking. It is good for type 2 diabetic patients as it reduces blood sugar levels in the bodies.",
      image: product4,
      categoryImage: categoryImage1,
      count: 13,
      products: [
        {
          id: 401,
          name: "Dehydrated Curry Leaves Powder",
          description:
            "Dehydrated Curry Leaves Powder is a highly aromatic, nutrient-rich powder made from fresh curry leaves, carefully dehydrated to preserve their natural flavor and health benefits. Rich in antioxidants, vitamins A, C, and B, along with essential minerals, this powder helps in digestion, promotes healthy hair, and supports overall wellness. Its importance lies in providing a convenient, shelf-stable version of fresh curry leaves, making it easy to incorporate into a variety of food, beverage, and supplement products. The specialty of this powder is its ability to retain the full nutritional value and distinct aroma of curry leaves, offering manufacturers a versatile, clean-label ingredient for boosting the flavor and health benefits of their products.",
          image: [c2product1, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Beetroot",
            Appearance: "Fine, slightly Coarse texture",
            Color: "Dark red color",
            Flavor_and_Aroma: "Stronger, earthy flavor",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into spice blends, soups, sauces, and curries to enhance flavor and aroma.",
            Health_Supplements:
              "Added to dietary supplements for its potential health benefits, including supporting digestion and regulating blood sugar levels.",
            Cosmetics:
              "Used in skincare products for its antioxidant and anti-inflammatory properties.",
            Animal_Feed:
              "Included in livestock feed to improve digestion and overall health.",
          },
          NutritionalValue: {
            Vitamin_A:
              "~2000-3000 IU per 100g – Supports vision and immune health.",
            Vitamin_C:
              "~20-30 mg per 100g – Boosts immunity and acts as an antioxidant.",
            Calcium: "~300-400 mg per 100g – Essential for bone health.",
            Iron: "~10-15 mg per 100g – Important for oxygen transport and energy production.",
            Folate_Vitamin_B:
              "~50-70 µg per 100g – Aids in cell function and growth.",
            Magnesium:
              "~100-150 mg per 100g – Supports muscle and nerve function.",
            Fiber: "~10-15g per 100g – Aids digestion and supports gut health.",
          },
        },
        {
          id: 402,
          name: "Dehydrated Mint Powder",
          description:
            "Dehydrated Mint Powder is a fresh, natural powder made from mint leaves that are carefully dehydrated to preserve their refreshing flavor, aroma, and health benefits. Packed with essential vitamins, antioxidants, and anti-inflammatory properties, this powder supports digestion, boosts immunity, and provides a soothing effect. Its importance lies in offering a shelf-stable, easy-to-use form of mint, perfect for adding flavor and health benefits to a wide range of products such as beverages, teas, and cosmetics. The specialty of this powder is its concentrated form, retaining the full essence of mint in a convenient, long-lasting product that can enhance both food and wellness formulations.",
          image: [c2product1, product2, product3],
          productSpecification: {
            Ingredients: "Fresh Beetroot",
            Appearance: "Fine, slightly Coarse texture",
            Color: "Dark red color",
            Flavor_and_Aroma: "Stronger, earthy flavor",
            Moisture_content: "7-10%",
            Solubility: "95%",

            Partical_Size:
              "Mesh size of 80-100 micron(As per customer requirements).",
            Shelf_Life: "9 to 12 months when stored in a cool, dry place.",
          },
          application: {
            Food_and_Beverage:
              "Incorporated into sauces, soups, dressings, and beverages to enhance flavor and aroma.",
            Health_Supplements:
              "Added to dietary supplements for its potential health benefits, including aiding digestion and providing antioxidant properties.",
            Cosmetics:
              "Used in skincare products for its cooling effect and potential to soothe skin irritations.",
            Animal_Feed:
              "Included in livestock feed to improve digestion and overall health.",
          },
          NutritionalValue: {
            Vitamin_A:
              "~3000-4000 IU per 100g – Supports vision, skin, and immune health.",
            Vitamin_C:
              "~50-60 mg per 100g – Boosts immunity and acts as an antioxidant.",
            Iron: "~10-12 mg per 100g – Essential for oxygen transport and energy production.",
            Calcium: "~200-300 mg per 100g – Supports bone and dental health.",
            Magnesium:
              "~100-150 mg per 100g – Aids muscle function and nerve health.",
            Fiber:
              "~15-20g per 100g – Promotes digestion and supports gut health.",
          },
        },
      ],
    },
  ];
  const newArrival = [
    {
      id: 101,
      name: "Beetroot Powder",
      image: product1,
    },
    {
      id: 102,
      name: "Beetroot Powder",
      image: product2,
    },
    {
      id: 103,
      name: "Beetroot Powder",
      image: product3,
    },
    {
      id: 104,
      name: "Beetroot Powder",
      image: product4,
    },
  ];

  return (
    <CategoriesContext.Provider value={{ categories, newArrival }}>
      {children}
    </CategoriesContext.Provider>
  );
};

export const useCategories = () => useContext(CategoriesContext);

export default CategoriesProvider;
