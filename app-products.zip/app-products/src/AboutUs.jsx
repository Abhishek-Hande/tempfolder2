import React from "react";
import Header from "./components/Header";
import { Row, Col } from "react-bootstrap";
import ProductCard from "./components/ProductCard";
import ContactForm from "./components/ContactForm";
import Footer from "./components/Footer";
import styles from "./AboutUs.module.css";
import sampleImage from "@/assets/pic9.png";

export default function AboutUs() {
  return (
    <section>
      <section id="About-us-banner" className={styles.bannar}>
        <div className="container">
          <div className={styles.bannerElement}>
            <div>
              <h1 className={styles.pageTitle}>About us</h1>

              <div>
                <ul className={styles.breadcrumb}>
                  <li>
                    <a href="http://localhost:5173/">Home </a>
                  </li>
                  <li>About Us</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="aboutUsInfo" className="container">
        <div className={styles.wrapper}>
          <img
            className={styles.companyProfile}
            src="https://www.meviveinternational.com/data/storage/app/images/about/1633359149.webp"
            // src={sampleImage}
            alt="Company Image"
          />
          <div>
            <h4 className={styles.spanColor}>Who we are</h4>
          </div>
          <div>
            {/* <h2 class={styles.homeAboutHeading}>Let’s Serve Taste with Purity</h2> */}
            <h1 className={styles.homeAboutHeading}>
              India's Trusted Company of Premium Quality Food Ingredients
            </h1>
          </div>
          <div>
            <p>
              Natural Eco Agro established in 2018 &amp; headquartered at Pune,
              Maharashtra, India - is engaged in “Sourcing, Value-Adding &amp;
              Exporting superior quality food ingredients”. We source from the
              origin of the raw material to ensure quality and price advantage.
              The products are then moved to our facility at Junnar, Pune for
              value addition as per customer specifications. With the experience
              &amp; expertise of our adroit workforce, we have been able to
              position ourselves in the market as one of the most reliable
              companies in the food ingredient business. Our aim is to redefine
              the market standards when it comes to Quality, Service and
              Customer Satisfaction.
            </p>
            <h4 className={styles.spanColor}>Our Infrastructure</h4>
            <p>
              We are having 2,937 Square Meter work area with 1 MT Per day
              production capacity, 1 Spray Dryers & Dehydration Units. All
              operations of Natural Eco Agro are in accordance with the
              international food quality norms, from the procuring stage to the
              final dispatch, the products undergo from number of various
              proccesses. Each stage is monitored closely by highly qualified
              staff from the state of the art quality control laboratory.
            </p>
            <p>
              We are a manufacture of approximately 50 products in different
              categories. Our products reach out to 8 countries globally and
              more than 50 cities in India. We aspire to be a globally
              recognized organization in the processed food industry. We have a
              team of more than 25 members for achieving the customer
              satisfaction through innovative and sustainable solutions.
            </p>
          </div>
        </div>
      </section>
    </section>
  );
}
